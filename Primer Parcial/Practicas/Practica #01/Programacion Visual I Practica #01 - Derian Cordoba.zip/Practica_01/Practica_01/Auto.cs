﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_01
{
    class Auto
    {
        public string Marca { get; set; }
        public string Estado { get; set; }
        public string Transmision { get; set; }
        public string Rines { get; set; }
        public double Precio { get; set; }
        public double Kilometraje { get; set; }

    }
}
